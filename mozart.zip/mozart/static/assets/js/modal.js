function openModal2() {
    document.querySelector('.modaltwo').style.display = 'flex';
}

// Function to close the modal
function closeModal2() {
    document.querySelector('.modaltwo').style.display = 'none';
}